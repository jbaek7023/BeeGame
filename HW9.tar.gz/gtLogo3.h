#ifndef GTBEE_BITMAP_H
#define GTBEE_BITMAP_H
extern const unsigned short gtLogo3[100];
#define GTBEE_WIDTH 10
#define GTBEE_HEIGHT 10
#endif
