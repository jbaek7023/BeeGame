#ifndef BULLDOG15_BITMAP_H
#define BULLDOG15_BITMAP_H
extern const unsigned short bullDog15[240];
#define BULLDOG15_WIDTH 16
#define BULLDOG15_HEIGHT 15
#endif