'BEE ADVENTURE' 

Your bee want to go to honeycomb section to eat honey. 
However, there are obstacles(pipes) interuptting you from honeycomb section. 
If you win, you can see the georgia tech trade mark. 

life is HP. If your HP is 0, your bee will be dead

You can reset any time you want with SELECT key (GBA Select key should be delete key in keyboard)

(!!) You might think my pipes have tearings between top and bottom. But the image has a black gap originally. So it's not tearing!! Just to make sure I'm uploading one of pipes in to the zip file.

Thanks,
Jae Min Baek


