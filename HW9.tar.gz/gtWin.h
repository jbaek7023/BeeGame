#ifndef GTWIN_BITMAP_H
#define GTWIN_BITMAP_H
extern const unsigned short gtWin[38400];
#define GTWIN_WIDTH 240
#define GTWIN_HEIGHT 160
#endif