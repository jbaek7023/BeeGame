#ifndef BULLDOG30_BITMAP_H
#define BULLDOG30_BITMAP_H
extern const unsigned short bullDog30[480];
#define BULLDOG30_WIDTH 16
#define BULLDOG30_HEIGHT 30
#endif