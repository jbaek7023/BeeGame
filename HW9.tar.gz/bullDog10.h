#ifndef BULLDOG10_BITMAP_H
#define BULLDOG10_BITMAP_H
extern const unsigned short bullDog10[160];
#define BULLDOG10_WIDTH 16
#define BULLDOG10_HEIGHT 10
#endif