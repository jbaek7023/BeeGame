#ifndef BULLDOG5_BITMAP_H
#define BULLDOG5_BITMAP_H
extern const unsigned short bullDog5[80];
#define BULLDOG5_WIDTH 16
#define BULLDOG5_HEIGHT 5
#endif