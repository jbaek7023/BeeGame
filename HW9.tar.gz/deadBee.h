#ifndef DEADBEE_BITMAP_H
#define DEADBEE_BITMAP_H
extern const unsigned short deadBee[38400];
#define DEADBEE_WIDTH 240
#define DEADBEE_HEIGHT 160
#endif