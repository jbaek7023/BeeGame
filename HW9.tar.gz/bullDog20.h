#ifndef BULLDOG20_BITMAP_H
#define BULLDOG20_BITMAP_H
extern const unsigned short bullDog20[320];
#define BULLDOG20_WIDTH 16
#define BULLDOG20_HEIGHT 20
#endif